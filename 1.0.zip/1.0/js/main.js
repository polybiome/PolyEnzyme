$(document).ready(function(){

	$(window).scroll(function(){
		var scroll = $(window).scrollTop();
		if (scroll >= 200){
			$(".navbar-fixed-top").addClass('navbarEffect');
		} else{
			$(".navbar-fixed-top").removeClass('navbarEffect');
		}
	});
});

smoothScroll.init({
	speed: 700,
	easing: 'easeInOutQuad',
	updateURL: false,
	offset: 51,
});