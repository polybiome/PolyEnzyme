$(document).ready(function(){
	window.alert("WARNING: This page is in pre-alpha version. \nDesign, layout and other aspects are subject to change, and bugs are expected. CONTINUE AT YOUR OWN RISK.\n\nTo change theme click the buttons at the page bottom.");
	$(window).scroll(function(){
		var scroll = $(window).scrollTop();
		if (scroll >= 200){
			$(".navbar-fixed-top").addClass('navbarEffect');
		} else{
			$(".navbar-fixed-top").removeClass('navbarEffect');
		}
	});

	$('#main .col-md-4').waypoint(function(){
		$('#main img').addClass('animated slideInRight');
		$('#main img').css({'opacity':1});
	}, {offset: '40%'
	});

	$('#temp #dark').click(function(){
        $("#slider img").attr("src","img/logoDrac.png");
        $('link[href="css/main.css"]').attr('href','css/mainDark.css');
	});
	$('#temp #clear').click(function(){
		$("#slider img").attr("src","img/LOGOorange.png");
        $('link[href="css/mainDark.css"]').attr('href','css/main.css');
	});
	$('#temp #nope').click(function(){

	});
});

smoothScroll.init({
	speed: 700,
	easing: 'easeInOutQuad',
	updateURL: false,
	offset: 51,
});