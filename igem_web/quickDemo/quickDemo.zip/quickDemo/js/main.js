$(document).ready(function(){

	var nav = $(".navbar-fixed-top");
	var distance = $(".navbar-fixed-top").offset();

	if (distance.top >= 200){
		nav.addClass('effect');
		$('.navbar-nav').removeClass('darker')

	}

	$("body").waypoint(function(){ 

		if ($(window).width() < 768){
		$('.navbar-nav').addClass('darker')
		}else{$('.navbar-nav').removeClass('darker')}
		
	});


	$(window).scroll(function(){

		var scroll = $(window).scrollTop();
		console.log(scroll);
		if (scroll >= 200){
			nav.addClass('effect');
			$('.navbar-nav').removeClass('darker')


		} else{

			nav.removeClass('effect');

			if ($(window).width() < 768){
				$('.navbar-nav').addClass('darker')
			}else{$('.navbar-nav').removeClass('darker')}

		}

	});

	$('.achivements-image').waypoint(function(){ 

		$('.animation1').css({'opacity':1});
		$(this.element).addClass('animated fadeInUp');
		
		}, {offset: '50%'}

	);

	$('.people .col-sm-4').waypoint(function(){ 

		$(this.element).addClass('animated zoomIn');
		$(this.element).css({'opacity':1});
	}, {offset: '50%'
	});

});
